import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ExtMethodService {

  constructor(private http:HttpClient, public router:Router) { }
  type = "3"
  // set_employe_type(employee_type:any){
  //   if (employee_type=="Employee"){
  //     return this.type
  //   }
  //   if (employe_type=="Manager"){
  //     return "2"
  //   }
  //   if (employe_type=="Admin"){
  //     return "2"
  //   }
  // }

}
