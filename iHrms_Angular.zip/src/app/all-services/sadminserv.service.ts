import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http'
import { config } from '../config';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class SadminservService {

  constructor(private http:HttpClient, public router:Router) { }
  get_all_data(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/get_all_data`, data.body, { headers });
  }
  
  monthly_attendance_record(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/monthly_attendance_record`, data, { headers });
  }

  holyday_record(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/holyday_record`, data, { headers });
  }

  all_attendance_record(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/all_attendance_record`, data, { headers });
  }

  birthday_record(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/birthday_record`, data, { headers });
  }

  get_employname(){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/get_employname`, null, { headers });
  }

  get_screenshot(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/get_screenshot`, data.body, { headers });
  }

  get_punch_tracking(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/get_punch_tracking`, data.body, { headers });
  }

  get_feed_employee(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/get_feed_employee`, data.body, { headers });
  }

  get_manager(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/get_manager`, data.body, { headers });
  }

  admin_get_screenshot(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/admin_get_screenshot`, data.body, { headers });
  }

  admin_attendance_record(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/admin_attendance_record`, data.body, { headers });
  }

  get_leave_balance(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/get_leave_balance`, data.body, { headers });
  }

  get_leave_data(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/get_leave_data`, data.body, { headers });
  }

  get_leave_summary(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/admin_leave_summary`, data.body, { headers });
  }


  get_admin_attendance_record(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/admin_attendance_record`, data.body, { headers });
  }
  // attendance_record(data:any){
  //   const headers = {
  //     "Authorization":"Bearer "+localStorage.getItem('access_token')
  //    };
  //   return this.http.post<any>(`${config.API_URL}/admin_attendance_record`, data.body, { headers });
  // }


  get_profile_data(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
     };
    return this.http.post<any>(`${config.API_URL}/get_profile_data`, data.body, { headers });
  }


  refresh_api(refresh_token:any){
    return this.http.post<any>(`${config.API_URL}/refresh_token`, {
      "refresh_token": refresh_token
    });

  }


  clear_refresh_token(error_status:any){
    // if (error_status==408){
    //   localStorage.clear();
    //   this.router.navigate(['/']);
    // }
    console.log("==================>>> inside clear_refresh_token ")
    localStorage.clear();
    this.router.navigate(['/']);
  }

  register_employee(data:any){
    const headers = {
      "Authorization":"Bearer "+localStorage.getItem('access_token')
    };
    return this.http.post<any>(`${config.API_URL}/register`, data, { headers });
  }


}
