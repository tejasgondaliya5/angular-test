import { TestBed } from '@angular/core/testing';

import { SadminservService } from './sadminserv.service';

describe('SadminservService', () => {
  let service: SadminservService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SadminservService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
