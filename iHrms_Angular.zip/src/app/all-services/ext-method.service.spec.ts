import { TestBed } from '@angular/core/testing';

import { ExtMethodService } from './ext-method.service';

describe('ExtMethodService', () => {
  let service: ExtMethodService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ExtMethodService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
