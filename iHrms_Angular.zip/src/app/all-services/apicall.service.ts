import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Subject } from 'rxjs';
import { config } from '../config';


@Injectable({
  providedIn: 'root'
})

export class ApicallService {
  private ishiddenselect = new Subject<boolean>();
  ishidden$ = this.ishiddenselect.asObservable();

  constructor(private http:HttpClient) { }
  isdisable = true
  
  get_isdisable(){
    return this.isdisable
  }

  set_isdisable(val:boolean){
    this.ishiddenselect.next(val)
  }
  
  loginapi(data:any){
    return this.http.post<any>(`${config.API_URL}/login`, data);
  }

}
