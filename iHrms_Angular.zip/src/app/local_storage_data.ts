export let local_storage_data = {
    localStorage_string_convert_json_formate(){
        var chack_object_data = localStorage.getItem('Employee_data')
        if (chack_object_data != null){
            let jsonObj = JSON.parse(chack_object_data);
            return jsonObj
        }
        else{
            return "data not found."
            // return {"message":"manager_id not found"}
        }
    }
}
