import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SadminservService } from 'src/app/all-services/sadminserv.service';


interface LeaveSummaryItem {
  name: string;
  total_leave: string;
  taken: string;
  available: string;
  unlockdleaves: string;
}

interface LeaveSummaryColumnItem {
  name: string;
}



@Component({
  selector: 'app-leave-summary',
  templateUrl: './leave-summary.component.html',
  styleUrls: ['./leave-summary.component.scss']
})
export class LeaveSummaryComponent implements OnInit {

  PageIndex = 1000;
  Total_data = 10;
  PageSize = 10;
  userdata=this.employee_id.snapshot.paramMap.get("id");


  constructor(private employee_id:ActivatedRoute, public router:Router, private sadminservService:SadminservService) {}

  ngOnInit(): void {
    console.log("inside leave summary")
    this.get_leave_summary({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
  }


  new_access_token():void{
    this.sadminservService.refresh_api(localStorage.getItem('refresh_token')).subscribe({next: (data)=>{
      console.log(data)
      localStorage.setItem('access_token', data.Response.data.access_token);
      this.get_leave_summary({"employid":this.userdata})
    },
    error: (e) => {
        console.log(e);
        console.log(e.status);
        this.sadminservService.clear_refresh_token(e.status)
        this.router.navigate(['/login']);
      }
    });
  }

  get_leave_summary(data:any){
    this.sadminservService.get_leave_summary({"body":data}).subscribe({next: (data)=>{
    console.log(data.Response.data)
    // this.LeaveSummaryListOfData = []
    this.LeaveSummaryListOfData = data.Response.data;
    this.PageIndex = data.Response.currentpage
    this.Total_data = data.Response.totalrecord
    this.PageSize = data.Response.parPage
    },error: (e) => {
      // console.log(e);
      // console.log(e.status);
      var new_access_token = this.new_access_token()
      }
    });
  }


  page_num = 1
  get_page_num(data:any){
    if(data.target.text){
      this.page_num = Number(data.target.text)
      // this.get_punch_tracking_api({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
      }
  }


  get_page_size(data:any){
    this.page_num=1
    this.PageSize = data
    // this.get_punch_tracking_api({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
  }

  LeaveSummaryListOfData: LeaveSummaryItem[] = [];

  leaveSummarylistOfColumns: LeaveSummaryColumnItem[] = [
    {
      name: 'TYPE',
    },
    {
      name: 'TOTAL',
    },
    {
      name: 'TAKEN',
    },
    {
      name: 'AVAILABLE',
    },
    {
      name: 'UNLOCKED LEAVES',
    },
  ];



}
