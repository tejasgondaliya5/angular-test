import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SadminservService } from 'src/app/all-services/sadminserv.service';


// interface Attendance {
//   "Date": String;
//   "First_In":String;
//   "Last_Out":String,
//   "Duration":String,
//   "Type":String,
//   "status":String
// }

interface Attendance {
  date: string;
  In: string;
  Out: string;
  total_duration: string;
  Type: string;
  status: string;
}

@Component({
  selector: 'app-monthly-attendance',
  templateUrl: './monthly-attendance.component.html',
  styleUrls: ['./monthly-attendance.component.scss']
})
export class MonthlyAttendanceComponent implements OnInit {

  userdata=this.employee_id.snapshot.paramMap.get("id");

  constructor(private employee_id:ActivatedRoute, public router:Router, private sadminservService:SadminservService) { }

  ngOnInit(): void {
    this.get_admin_attendance_record({"employid":this.userdata, "date":"2022-08"})
  }

  get_admin_attendance_record(data:any){
    this.sadminservService.admin_attendance_record({"body":data}).subscribe({next: (data)=>{
      // console.log(data.Response.currentpage)
      // if(total_page>)

        // console.log("this.listOfData", this.listOfData)
        this.monthaly_attendance = data.Response.data
      },error: (e) => {
        console.log(e);
        console.log(e.status);
        var new_access_token = this.new_access_token()
        }
      });
  }

  new_access_token():void{
    this.sadminservService.refresh_api(localStorage.getItem('refresh_token')).subscribe({next: (data)=>{
      console.log(data)
      localStorage.setItem('access_token', data.Response.data.access_token);
      this.get_admin_attendance_record({"employid":this.userdata})
    },
    error: (e) => {
        console.log(e);
        console.log(e.status);
        this.sadminservService.clear_refresh_token(e.status)
        this.router.navigate(['/login']);
      }
    });
  }

  onValueChange(value: Date): void {
    console.log(`Current value: ${value}`);
  }
  test_date = "2022-09-01"

  monthaly_attendance : Attendance[] = [];
  // monthaly_attendance = [
  //   {
  //     "Date":"31 August 2022",
  //     "First_In":"09:21 AM",
  //     "Last_Out":"09:21 AM",
  //     "Duration":"15:00:21",
  //     "Type":"Full Day",
  //     "status":"P"
  //   },
    // {
    //   "Date":"31 August 2022",
    //   "First_In":"09:21 AM",
    //   "Last_Out":"09:21 AM",
    //   "Duration":"15:00:21",
    //   "Type":"Full Day",
    //   "status":"P"
    // },
    // {
    //   "Date":"31 August 2022",
    //   "status":"AB"
    // },
    // {
    //   "Date":"31 August 2022",
    //   "First_In":"09:21 AM",
    //   "Last_Out":"09:21 AM",
    //   "Duration":"15:00:21",
    //   "Type":"Full Day",
    //   "status":"P"
    // },
    // {
    //   "Date":"31 August 2022",
    //   "Type":"Full Day",
    //   "status":"L"
    // },
    // {
    //   "Date":"31 August 2022",
    //   "First_In":"09:21 AM",
    //   "Last_Out":"09:21 AM",
    //   "Duration":"15:00:21",
    //   "Type":"Full Day",
    //   "status":"P"
    // },
    // {
    //   "Date":"31 August 2022",
    //   "First_In":"09:21 AM",
    //   "Last_Out":"09:21 AM",
    //   "Duration":"15:00:21",
    //   "Type":"Full Day",
    //   "status":"P"
    // },
  // ]

}
