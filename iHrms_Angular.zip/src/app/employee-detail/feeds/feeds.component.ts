import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NzTableFilterFn, NzTableSortFn, NzTableFilterList, NzTableSortOrder } from 'ng-zorro-antd/table';
import { SadminservService } from 'src/app/all-services/sadminserv.service';

interface LeaveItem {
  Name: string;
  date_time: string;
  friendly_date: string;
}

interface LeaveColumnItem {
  name: string;
  sortOrder: NzTableSortOrder | null;
  sortFn: NzTableSortFn<LeaveItem> | null;
  listOfFilter: NzTableFilterList;
  filterFn: NzTableFilterFn<LeaveItem> | null;
}

@Component({
  selector: 'app-feeds',
  templateUrl: './feeds.component.html',
  styleUrls: ['./feeds.component.scss']
})
export class FeedsComponent implements OnInit {

  // menu_selected =true
  PageIndex = 1000;
  Total_data = 10;
  PageSize = 10;
  page_num=1
  userdata=this.employee_id.snapshot.paramMap.get("id");

  constructor(private employee_id:ActivatedRoute, public router:Router, private sadminservService:SadminservService) { }

  ngOnInit(): void {
    this.get_leave({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
  }

  get_leave(data:any){
    this.sadminservService.get_feed_employee({"body":data}).subscribe({next: (data)=>{
    console.log(data.Response.data)
    // this.LeaveSummaryListOfData = []
    this.leaveListOfData = data.Response.data;
    this.PageIndex = data.Response.currentpage
    this.Total_data = data.Response.totalrecord
    this.PageSize = data.Response.parPage
    },error: (e) => {
      // console.log(e);
      // console.log(e.status);
      var new_access_token = this.new_access_token()
      }
    });
  }

  new_access_token():void{
    this.sadminservService.refresh_api(localStorage.getItem('refresh_token')).subscribe({next: (data)=>{
      console.log(data)
      localStorage.setItem('access_token', data.Response.data.access_token);
      this.get_leave({"employid":this.userdata})
    },
    error: (e) => {
        console.log(e);
        console.log(e.status);
        this.sadminservService.clear_refresh_token(e.status)
        this.router.navigate(['/login']);
      }
    });
  }

  get_page_size(data:any){
    this.page_num=1
    this.PageSize = data
    this.get_leave({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
    // this.get_punch_tracking_api({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize}) // call API For the Pagenation for the 
  }

  get_page_num(data:any){
    if(data.target.text){
      this.page_num = Number(data.target.text)
      this.get_leave({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
      // this.get_punch_tracking_api({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})     // call API For the Pagenation for the 
      }
  }
  leaveListOfData: LeaveItem[] = [];

  leavelistOfColumns: LeaveColumnItem[] = [
    {
      name: 'Action',
      sortOrder: null,
      sortFn: (a: LeaveItem, b: LeaveItem) => a.Name.localeCompare(b.Name),
      listOfFilter: [
        { text: 'Punch Out', value: 'Punch Out'},
        { text: 'Punch In', value: 'Punch In'}
      ],
      filterFn: (list: string[], item: LeaveItem) => list.some(name => item.Name.indexOf(name) !== -1)
    },

    {
      name: 'Date/Time',
      sortFn: null,
      sortOrder: null,
      listOfFilter: [],
      filterFn: (DAY: string, item: LeaveItem) => item.date_time.indexOf(DAY) !== -1
    },

    {
      name: 'Friendly Date',
      sortOrder: null,
      sortFn: null,
      listOfFilter: [],
      filterFn: null
    }
  ];

  trackByName(_: number, item: LeaveColumnItem): string {
    return item.name;
  }
}
