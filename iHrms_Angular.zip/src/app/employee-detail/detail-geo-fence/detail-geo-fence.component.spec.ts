import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailGeoFenceComponent } from './detail-geo-fence.component';

describe('DetailGeoFenceComponent', () => {
  let component: DetailGeoFenceComponent;
  let fixture: ComponentFixture<DetailGeoFenceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetailGeoFenceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailGeoFenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
