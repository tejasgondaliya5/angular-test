import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-geo-fence',
  templateUrl: './detail-geo-fence.component.html',
  styleUrls: ['./detail-geo-fence.component.scss']
})
export class DetailGeoFenceComponent implements OnInit {

  punchin: Array<{ label: string; value: string }> = [];
  punchintag = [];

  punchout: Array<{ label: string; value: string }> = [];
  punchouttag = [];
  
  constructor() { }

  ngOnInit(): void {
  }

}
