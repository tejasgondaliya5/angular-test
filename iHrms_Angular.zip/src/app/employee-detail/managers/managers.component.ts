import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SadminservService } from 'src/app/all-services/sadminserv.service';


interface LeaveManagerItem {
  s_no: number;
  name: string;
  identity: string;
  mobile_num: string;
  email: string;
}

interface LeaveSummaryColumnItem {
  name: string;
}


@Component({
  selector: 'app-managers',
  templateUrl: './managers.component.html',
  styleUrls: ['./managers.component.scss']
})
export class ManagersComponent implements OnInit {

  PageIndex = 1000;
  Total_data = 10;
  PageSize = 10;
  userdata=this.employee_id.snapshot.paramMap.get("id");


  constructor(private employee_id:ActivatedRoute, public router:Router, private sadminservService:SadminservService) {}

  ngOnInit(): void {
    this.get_manager_data({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
  }


  new_access_token():void{
    this.sadminservService.refresh_api(localStorage.getItem('refresh_token')).subscribe({next: (data)=>{
      console.log(data)
      localStorage.setItem('access_token', data.Response.data.access_token);
      this.get_manager_data({"employid":this.userdata})
    },
    error: (e) => {
        console.log(e);
        console.log(e.status);
        this.sadminservService.clear_refresh_token(e.status)
        this.router.navigate(['/login']);
      }
    });
  }

  get_manager_data(data:any){
    this.sadminservService.get_manager({"body":data}).subscribe({next: (data)=>{
    console.log(data.Response.data)
    // this.LeaveSummaryListOfData = []
    this.LeaveManagerListOfData = data.Response.data;
    this.PageIndex = data.Response.currentpage
    this.Total_data = data.Response.totalrecord
    this.PageSize = data.Response.parPage
    },error: (e) => {
      // console.log(e);
      // console.log(e.status);
      var new_access_token = this.new_access_token()
      }
    });
  }


  page_num = 1
  get_page_num(data:any){
    if(data.target.text){
      this.page_num = Number(data.target.text)
      // this.get_punch_tracking_api({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
      }
  }


  get_page_size(data:any){
    this.page_num=1
    this.PageSize = data
    // this.get_punch_tracking_api({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
  }

  LeaveManagerListOfData: LeaveManagerItem[] = [];

  leaveSummarylistOfColumns: LeaveSummaryColumnItem[] = [
    {
      name: 'S.No',
    },
    {
      name: 'NAME',
    },
    {
      name: 'IDENTITY',
    },
    {
      name: 'MO.NO',
    },
    {
      name: 'EMAIL',
    }
    
  ];



}
