import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailOrganizatonsComponent } from './detail-organizatons.component';

describe('DetailOrganizatonsComponent', () => {
  let component: DetailOrganizatonsComponent;
  let fixture: ComponentFixture<DetailOrganizatonsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetailOrganizatonsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailOrganizatonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
