import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-organizatons',
  templateUrl: './detail-organizatons.component.html',
  styleUrls: ['./detail-organizatons.component.scss']
})
export class DetailOrganizatonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
  autopunchout_switchValue = false;

  autopunchout_switch(){
    this.autopunchout_switchValue = !this.autopunchout_switchValue
  }
  type_drpd = ["Manager", "Admin", "Employee"]

  select_data="Employee";

  type_dropdown(type_data:any){
    console.log("type_data", typeof type_data.target.value)
    console.log("type_data", type_data.target.value)
    if(type_data.target.value=="Employee"){
      this.select_data = type_data.target.value
    }
    else if(type_data.target.value=="Manager"){
      this.select_data = type_data.target.value
    }
    else if(type_data.target.value=="Admin"){
      this.select_data = type_data.target.value
    }
  }


}
