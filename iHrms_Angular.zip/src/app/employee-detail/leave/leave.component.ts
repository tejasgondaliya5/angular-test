import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NzTableFilterFn, NzTableSortFn, NzTableFilterList, NzTableSortOrder } from 'ng-zorro-antd/table';
import { SadminservService } from 'src/app/all-services/sadminserv.service';

interface LeaveItem {
  type: string;
  status: string;
  day_type: string;
  leave_from: string;
  leave_to: string;
  WorkDate: string;
  leave_duration: string;
  is_created: string;
}

interface LeaveColumnItem {
  name: string;
  sortOrder: NzTableSortOrder | null;
  sortFn: NzTableSortFn<LeaveItem> | null;
  listOfFilter: NzTableFilterList;
  filterFn: NzTableFilterFn<LeaveItem> | null;
}


@Component({
  selector: 'app-leave',
  templateUrl: './leave.component.html',
  styleUrls: ['./leave.component.scss']
})
export class LeaveComponent implements OnInit {

  PageIndex = 1000;
  Total_data = 10;
  PageSize = 10;
  page_num=1
  userdata=this.employee_id.snapshot.paramMap.get("id");

  constructor(private employee_id:ActivatedRoute, public router:Router, private sadminservService:SadminservService) { }

  ngOnInit(): void {
    this.get_leave({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
  }

  get_leave(data:any){
    this.sadminservService.get_leave_data({"body":data}).subscribe({next: (data)=>{
    console.log(data.Response.data)
    // this.LeaveSummaryListOfData = []
    this.leaveListOfData = data.Response.data;
    this.PageIndex = data.Response.currentpage
    this.Total_data = data.Response.totalrecord
    this.PageSize = data.Response.parPage
    },error: (e) => {
      // console.log(e);
      // console.log(e.status);
      var new_access_token = this.new_access_token()
      }
    });
  }

  new_access_token():void{
    this.sadminservService.refresh_api(localStorage.getItem('refresh_token')).subscribe({next: (data)=>{
      console.log(data)
      localStorage.setItem('access_token', data.Response.data.access_token);
      this.get_leave({"employid":this.userdata})
    },
    error: (e) => {
        console.log(e);
        console.log(e.status);
        this.sadminservService.clear_refresh_token(e.status)
        this.router.navigate(['/login']);
      }
    });
  }

  get_page_size(data:any){
    this.page_num=1
    this.PageSize = data
    this.get_leave({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
    // this.get_punch_tracking_api({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize}) // call API For the Pagenation for the 
  }

  get_page_num(data:any){
    if(data.target.text){
      this.page_num = Number(data.target.text)
      this.get_leave({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})
      // this.get_punch_tracking_api({"employid":this.userdata, "page_num":this.page_num, "page_size": this.PageSize})     // call API For the Pagenation for the 
      }
  }
  leaveListOfData: LeaveItem[] = [];

  leavelistOfColumns: LeaveColumnItem[] = [
    {
      name: 'TYPE',
      sortOrder: null,
      sortFn: (a: LeaveItem, b: LeaveItem) => a.type.localeCompare(b.type),
      listOfFilter: [
        { text: 'Sick Leave', value: 'Sick Leave' },
        { text: 'Casual Leave', value: 'Casual Leave' }
      ],
      filterFn: (list: string[], item: LeaveItem) => list.some(name => item.type.indexOf(name) !== -1)
    },
    {
      name: 'STATUS',
      sortOrder: null,
      sortFn: null,
      listOfFilter: [],
      filterFn: null
    },
    {
      name: 'DAY',
      sortFn: null,
      sortOrder: null,
      listOfFilter: [],
      filterFn: (DAY: string, item: LeaveItem) => item.day_type.indexOf(DAY) !== -1
    },
    {
      name: 'FROM',
      sortFn: null,
      sortOrder: null,
      listOfFilter: [],
      filterFn: (FROM: string, item: LeaveItem) => item.leave_from.indexOf(FROM) !== -1
    },
    {
      name: 'TO',
      sortFn: null,
      sortOrder: null,
      listOfFilter: [],
      filterFn: (TO: string, item: LeaveItem) => item.leave_to.indexOf(TO) !== -1
    },
    {
      name: 'WORK DATE',
      sortFn: null,
      sortOrder: null,
      listOfFilter: [],
      filterFn: (WORKDATE: string, item: LeaveItem) => item.WorkDate.indexOf(WORKDATE) !== -1
    },
    {
      name: 'DURATION',
      sortFn: null,
      sortOrder: null,
      listOfFilter: [],
      filterFn: (DURATION: string, item: LeaveItem) => item.leave_duration.indexOf(DURATION) !== -1
    },
    {
      name: 'APPLIED ON',
      sortFn: null,
      sortOrder: null,
      listOfFilter: [],
      filterFn: (APPLIEDON: string, item: LeaveItem) => item.is_created.indexOf(APPLIEDON) !== -1
    },
  ];

  trackByName(_: number, item: LeaveColumnItem): string {
    return item.name;
  }

}
