import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, MinLengthValidator, ValidationErrors, Validators } from '@angular/forms';
import { Observable, Observer } from 'rxjs';
import { en_US, NzI18nService, zh_CN } from 'ng-zorro-antd/i18n'
import { SadminservService } from 'src/app/all-services/sadminserv.service';
import { ExtMethodService } from 'src/app/all-services/ext-method.service';
import { Router } from '@angular/router';
import { local_storage_data } from 'src/app/local_storage_data';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.scss']
})
export class AddEmployeeComponent implements OnInit {
  CreateEmployee: FormGroup;
  type_data = null;
  passwordVisible = false;
  password?: string;

  type_drpd = ["Manager", "Admin", "Employee"]
  bloodgroup_drpd = ["O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-", "H/H", "Unknown"]
  leaveprofile_drpd = ["Defualt"]

  emp_password_switchValue = false;
  manager_password_switchValue = false;
  admin_password_switchValue = false;
  Add_Employee_switchValue = false;
  Advance_Setting_switchValue = false;
  autopunchout_switchValue = false;

  gender = ["Male", "Female", "Others"]
  optionList: string[] = ["Male", "Female", "Others"];

  selectedUser = null;
  isLoading = false;
  date = null;
  isEnglish = false;
  isdisable_hidden = true;
  ishow_hidden = !this.isdisable_hidden

  punchin: Array<{ label: string; value: string }> = [];
  punchintag = [];

  punchout: Array<{ label: string; value: string }> = [];
  punchouttag = [];

  color_value = "#ffffff"

  //show change color value
  colorpicker(data:any){
    this.color_value = data.target.value
    console.log(this.color_value)
  }
  
  //set switch to password siled can show and hidden
  password_switch_func(){
    this.emp_password_switchValue = !this.emp_password_switchValue
  }

  //set add employe switch only show manager can manager can add employee or not
  add_employee_switch_func(){
    this.Add_Employee_switchValue = !this.Add_Employee_switchValue
  }

  //password switch in manager type manager
  manager_password_switch(){
    this.manager_password_switchValue = !this.manager_password_switchValue
  }
  
  //password switch in manager type admin
  admin_password_switch(){
    this.admin_password_switchValue = !this.admin_password_switchValue
  }
 

  Advance_Setting_switch_fun(){
    this.Advance_Setting_switchValue = !this.Advance_Setting_switchValue
    this.set_validter()
  }
  autopunchout_switch(){
    this.autopunchout_switchValue = !this.autopunchout_switchValue
  }
  

  select_data="Employee";
  
  type_dropdown(type_data:any){
    console.log("type_data", typeof type_data.target.value)
    console.log("type_data", type_data.target.value)
    if(type_data.target.value=="Employee"){
      this.select_data = type_data.target.value
    }
    else if(type_data.target.value=="Manager"){
      this.select_data = type_data.target.value
    }
    else if(type_data.target.value=="Admin"){
      this.select_data = type_data.target.value
    }
  }
 

  resetForm(e: MouseEvent): void {
    e.preventDefault();
    this.CreateEmployee.reset();
    for (const key in this.CreateEmployee.controls) {
      if (this.CreateEmployee.controls.hasOwnProperty(key)) {
        this.CreateEmployee.controls[key].markAsPristine();
        this.CreateEmployee.controls[key].updateValueAndValidity();
      }
    }
  }

  validateConfirmPassword(): void {
    setTimeout(() => this.CreateEmployee.controls['confirm'].updateValueAndValidity);
  }
  
  confirmValidator = (control: FormControl): { [s: string]: boolean } => {
    if (!control.value) {
      return { error: true, required: true };
    } else if (control.value !== this.CreateEmployee.controls['password'].value) {
      return { confirm: true, error: true };
    }
    return {};
  };

  // CreateEmployee = new FormGroup
  constructor(private fb: FormBuilder, private i18n: NzI18nService, public router:Router, private sadminservService:SadminservService, private extmethodService:ExtMethodService) {
    this.CreateEmployee = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      employid: ['', Validators.required],
      mobileno:['', Validators.maxLength(10)],
      usertype : [''],
      License :[''],
      password_switch : [],
      password :[''],
      advance_setting_switch :[''],
      add_employee_switch :[''],
      gender :[''],
      bloodgroup :[''],
      colorpicker :[''],
      dob :[''],
      date_joining :[''],
      address :[''],
      // geofence_restrictions_punchin :[[]],
      // geofence_restrictions_punchout :[[]],
      // geofence_restrictions_entry_alert :[[]],
      // geofence_restrictions_exit_alert :[[]],
      working_shifts :[''],
      leaveprofile :[''],
      disable_autopunchout_switch :[''],
    });
  }

  set_validter(){
    if(this.Advance_Setting_switchValue){
      this.CreateEmployee.get('gender')?.addValidators(Validators.required);
    }
  }

  submitForm(): void {
    console.log('submit', this.CreateEmployee.value);
  }

  ngOnInit(): void {
    this.CreateEmployee.controls["colorpicker"].setValue(this.color_value)
    this.CreateEmployee.controls["usertype"].setValue("Employee")
    console.log(this.CreateEmployee.controls["usertype"].setValue("Employee"))
  }
  
  set_register_request_data(data:any){
    console.log("befor changes data", data)
    // add employee switch set true=1 and flase=0 
    data.add_employee_switch = "0"
    if (data.add_employee_switch){
      data.add_employee_switch = "1"
    }

    data.advance_setting_switch = "0"
    if (data.advance_setting_switch){
      data.advance_setting_switch = "1"
    }

    data.disable_autopunchout_switch = "0"
    if (data.disable_autopunchout_switch){
      data.disable_autopunchout_switch = "1"
    }

    data.password_switch = "0"
    if (data.password_switch==true){
      data.password_switch = "1"
    }

    if(data.date_joining.length!=0){
      data.date_joining = new Date(data.date_joining).toISOString()
    }

    if(data.dob.length!=0){
      data.dob = new Date(data.dob).toISOString()
    }
    
    if(data.usertype=="Employee"){
      data.usertype=3
    }
    else if(data.usertype=="Manager"){
      data.usertype=2
    }
    else if(data.usertype=="Admin"){
      data.usertype=1
    }

    console.log("after changes data", data)
    data.created_at= 0

    // get employes id for the store local storage data
    var user_data = local_storage_data.localStorage_string_convert_json_formate()
    data.manager_id = user_data.employid
    return data
  } 

  onsubmit(data:any){
    if (this.CreateEmployee.valid) {
      console.log('submit', this.CreateEmployee.value);
      console.log(data.value)
      var request_data = this.set_register_request_data(data.value)
      this.sadminservService.register_employee(request_data).subscribe(data=>{
        if(data.status == "Success"){
          this.router.navigate(['/superadmin/home']);
        }
        
      })
    // this.sadminservService.register_employee()
    } else {
      Object.values(this.CreateEmployee.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }
}

