import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SadminservService } from 'src/app/all-services/sadminserv.service';
import { local_storage_data } from 'src/app/local_storage_data';
import { MdbModalRef, MdbModalService } from 'mdb-angular-ui-kit/modal';
import { NzTableFilterFn, NzTableSortFn, NzTableFilterList, NzTableSortOrder } from 'ng-zorro-antd/table';



@Component({
  selector: 'app-employe-detail',
  templateUrl: './employe-detail.component.html',
  styleUrls: ['./employe-detail.component.scss']
})
export class EmployeDetailComponent implements OnInit {
  fingerprint_scan_icon = "assets/images/fingerprint-scan.png"
  PageIndex = 1000;
  Total_data = 10;
  PageSize = 10;
  theam_size = "small"

  userdata=this.employee_id.snapshot.paramMap.get("id");
  modalRef: MdbModalRef<EmployeDetailComponent> | null = null;

  date = new Date();
  set_date_value?:String;

  constructor(private employee_id:ActivatedRoute, public router:Router, private sadminservService:SadminservService) { 
    this.month_onChange(this.date)
  }

  new_access_token():void{
    this.sadminservService.refresh_api(localStorage.getItem('refresh_token')).subscribe({next: (data)=>{
      console.log(data)
      localStorage.setItem('access_token', data.Response.data.access_token);
      this.get_user_profile_data({"employid":this.userdata})
    },
    error: (e) => {
        console.log(e);
        console.log(e.status);
        this.router.navigate(['/login']);
        this.sadminservService.clear_refresh_token(e.status)
      }
    });
  }

  user_name?:string;
  user_type?:string;
  user_id?:string;
  mobile_no?:string;
  user_email?:string;
  date_of_joining?:string;
  

  get_user_profile_data(data:any){
    this.sadminservService.get_profile_data({"body":data}).subscribe({next: (data)=>{
      console.log(data.Response)
      this.user_name = data.Response.data.name
      this.user_type = data.Response.data.user_type_name
      this.user_id = data.Response.data.employid
      this.mobile_no = data.Response.data.mobileno
      this.user_email = data.Response.data.email
      this.date_of_joining = data.Response.data.date_joining
    },error: (e) => {
      console.log(e);
      console.log(e.status);
      var new_access_token = this.new_access_token()
      }
    });
  }


  ngOnInit(): void {
    var Employee_data = localStorage.getItem('Employee_data')
    if(Employee_data){
    }
    else{
      this.router.navigate(['/superadmin/home']);
    }
    this.get_user_profile_data({"employid":this.userdata})
  }
  editStr = 'More Details';

  get_local_storage_data = local_storage_data.localStorage_string_convert_json_formate()
  
  name = this.get_local_storage_data.name


  tabs = [
    {
      name: 'Attendance',
    },
    {
      name: 'Monthly Attendance',
    },
    {
      name: 'Leave',
    },
    {
      name: 'Leave Summary',
    },
    {
      name: 'Leave Balance',
    },
    {
      name: 'Activity',
    },
    {
      name: 'Details',
    },
    {
      name: 'Managers',
    },
    {
      name: 'Documants',
    },
    {
      name: 'Feeds',
    },
  ];
  

  date_productivity = null;
  
  
  onChange(result: any) {
    console.log('onChange: ', result);
  }

  month_onChange(result: any): void {
    console.log('onChange: ', result);
    let month = this.date.getMonth()+1;
    let year = this.date.getFullYear();
    let fullDate = `${year}-${month}`;
    if (`${month}`.length===1){
      let fullDate = `${year}-0${month}`;
    }
    
    this.set_date_value = fullDate
    console.log("set_date_value", this.set_date_value)

  }

}



