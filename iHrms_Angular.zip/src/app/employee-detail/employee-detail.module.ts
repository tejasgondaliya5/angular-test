import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { EmployeeDetailRoutingModule } from './employee-detail-routing.module';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzFormModule } from 'ng-zorro-antd/form';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NzUploadModule } from 'ng-zorro-antd/upload';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { EmployeDetailComponent } from './employe-detail/employe-detail.component';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTypographyModule } from 'ng-zorro-antd/typography';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { MdbModalModule } from 'mdb-angular-ui-kit/modal';
import { MdbDropdownModule } from 'mdb-angular-ui-kit/dropdown';
import { MatButtonModule } from '@angular/material/button';
import { NzAvatarModule } from 'ng-zorro-antd/avatar';
import { NzCalendarModule } from 'ng-zorro-antd/calendar';
import { AttendanceComponent } from './attendance/attendance.component';
import { MonthlyAttendanceComponent } from './monthly-attendance/monthly-attendance.component';
import { LeaveComponent } from './leave/leave.component';
import { LeaveSummaryComponent } from './leave-summary/leave-summary.component';
import { LeaveBalanceComponent } from './leave-balance/leave-balance.component';
import { ActivityComponent } from './activity/activity.component';
import { ManagersComponent } from './managers/managers.component';
import { FeedsComponent } from './feeds/feeds.component';
import { DetailsComponent } from './details/details.component';
import { DetailBasicComponent } from './detail-basic/detail-basic.component';
import { DetailPersonalComponent } from './detail-personal/detail-personal.component';
import { DetailOrganizatonsComponent } from './detail-organizatons/detail-organizatons.component';
import { DetailGeoFenceComponent } from './detail-geo-fence/detail-geo-fence.component';
import { DocumentsComponent } from './documents/documents.component';
import { NzEmptyModule } from 'ng-zorro-antd/empty';


@NgModule({
  declarations: [
    AddEmployeeComponent,
    EmployeDetailComponent,
    AttendanceComponent,
    MonthlyAttendanceComponent,
    LeaveComponent,
    LeaveSummaryComponent,
    LeaveBalanceComponent,
    ActivityComponent,
    ManagersComponent,
    FeedsComponent,
    DetailsComponent,
    DetailBasicComponent,
    DetailPersonalComponent,
    DetailOrganizatonsComponent,
    DetailGeoFenceComponent,
    DocumentsComponent
  ],
  imports: [
    CommonModule,
    EmployeeDetailRoutingModule,
    NzTableModule,
    NzDropDownModule,
    NzIconModule,
    NzSelectModule,
    NzPaginationModule,
    NzCardModule,
    NzRadioModule,
    NzButtonModule,
    NzFormModule,
    ReactiveFormsModule,
    FormsModule,
    NzUploadModule,
    DragDropModule,
    NzSwitchModule,
    NzToolTipModule,
    NzInputModule,
    NzDatePickerModule,
    NzTabsModule,
    NzTypographyModule,
    NzModalModule,
    MdbDropdownModule,
    MdbModalModule,
    MatButtonModule,
    NzAvatarModule,
    NzCalendarModule,
    NzEmptyModule
  ],
  providers:[

  ],
  exports:[]
})
export class EmployeeDetailModule { }
