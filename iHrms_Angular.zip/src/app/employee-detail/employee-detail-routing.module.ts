import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ActivityComponent } from './activity/activity.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { AttendanceComponent } from './attendance/attendance.component';
import { DetailBasicComponent } from './detail-basic/detail-basic.component';
import { DetailsComponent } from './details/details.component';
import { EmployeDetailComponent } from './employe-detail/employe-detail.component';
import { FeedsComponent } from './feeds/feeds.component';
import { LeaveBalanceComponent } from './leave-balance/leave-balance.component';
import { LeaveSummaryComponent } from './leave-summary/leave-summary.component';
import { LeaveComponent } from './leave/leave.component';
import { ManagersComponent } from './managers/managers.component';
import { MonthlyAttendanceComponent } from './monthly-attendance/monthly-attendance.component';

const routes: Routes = [
  {
    path:"create",
    component:AddEmployeeComponent
  },
  {
    path:"employee_detail/:id",
    component:EmployeDetailComponent,
    children:[
      {
        path:"monthly-attendance",
        component:MonthlyAttendanceComponent
      },
      {
        path:"leave",
        component:LeaveComponent
      },
      {
        path:"leave-summary",
        component:LeaveSummaryComponent
      },
      {
        path:"leave-balance",
        component:LeaveBalanceComponent
      },
      {
        path:"activity",
        component:ActivityComponent
      },
      {
        path:"details",
        component:DetailsComponent,
        children:[
          {
            path:"",
            component:DetailBasicComponent,
          }
        ]
      },
      {
        path:"managers",
        component:ManagersComponent
      },
      {
        path:"feeds",
        component:FeedsComponent
      },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})



export class EmployeeDetailRoutingModule { }
