import { Component, OnInit } from '@angular/core';
import { NzUploadFile } from 'ng-zorro-antd/upload';
import { NzTabPosition } from 'ng-zorro-antd/tabs';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
  // userdata=this.employee_id.snapshot.paramMap.get("id");
  component_name = "Basic"
  constructor() { }

  list_name = ["Basic", "Personal", "Organizations", "Geo Fence"]
  onSelectComponent(name:any){
    this.component_name = name
    console.log("name", name)
  }

  ngOnInit(): void {
  }

}
