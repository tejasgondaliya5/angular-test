import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-basic',
  templateUrl: './detail-basic.component.html',
  styleUrls: ['./detail-basic.component.scss']
})
export class DetailBasicComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
