import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailBasicComponent } from './detail-basic.component';

describe('DetailBasicComponent', () => {
  let component: DetailBasicComponent;
  let fixture: ComponentFixture<DetailBasicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetailBasicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailBasicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
