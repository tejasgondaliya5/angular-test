import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-personal',
  templateUrl: './detail-personal.component.html',
  styleUrls: ['./detail-personal.component.scss']
})
export class DetailPersonalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  bloodgroup_drpd = ["O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-", "H/H", "Unknown"]
  color_value = "#ffffff"
  colorpicker(data:any){
    this.color_value = data.target.value
    console.log(this.color_value)
  }
  
}
