import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DesktopInsightsRoutingModule } from './desktop-insights-routing.module';
import { ScreenshotsComponent } from './screenshots/screenshots.component';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { FormsModule } from '@angular/forms';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzProgressModule } from 'ng-zorro-antd/progress';
import { NzAvatarModule } from 'ng-zorro-antd/avatar';
import { SortingPipe } from '../pipes/sorting.pipe';
import { NzEmptyModule } from 'ng-zorro-antd/empty';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzSliderModule } from 'ng-zorro-antd/slider';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';

@NgModule({
  declarations: [
    ScreenshotsComponent,
    SortingPipe
  ],
  imports: [
    CommonModule,
    DesktopInsightsRoutingModule,
    NzFormModule,
    FormsModule,
    NzDatePickerModule,
    NzDropDownModule,
    NzIconModule,
    NzSelectModule,
    NzRadioModule,
    NzInputModule,
    NzProgressModule,
    NzAvatarModule,
    NzEmptyModule,
    NzModalModule,
    NzButtonModule,
    NzSliderModule,
    NzSwitchModule,
    NzCheckboxModule,
    NzToolTipModule
  ],
})
export class DesktopInsightsModule { }

