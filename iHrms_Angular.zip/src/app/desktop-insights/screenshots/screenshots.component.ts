import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common'
import { Router } from '@angular/router';
import { local_storage_data } from 'src/app/local_storage_data';
import { SadminservService } from 'src/app/all-services/sadminserv.service';

interface emp_data_li {
  employid:string;
  name: string;
}

@Component({
  selector: 'app-screenshots',
  templateUrl: './screenshots.component.html',
  styleUrls: ['./screenshots.component.scss']
})

export class ScreenshotsComponent implements OnInit {
  fingerprint_scan_icon = "assets/images/fingerprint-scan.png"
  screenshot_icon = "assets/images/screenshot-icon.png"
  PageIndex = 1000;
  Total_data = 10;
  PageSize = 10;
  theam_size = "small"
  date = new Date();
  set_date_value?:String;
  
  selectedValue = null;

  radioValue = 'A';
  TooltipColor = 'rgba(14, 157, 127, 0.8)'
  sort_icon = true
  percent_value = 60
  employee_list : emp_data_li[] = [];
  sorting_type = 'asc'
  date_list!:any;
  set_date!:any;
  get_local_storage_data = local_storage_data.localStorage_string_convert_json_formate()
  
  employid = this.get_local_storage_data.employid
  
  inputValue?: string;
  filteredOptions: string[] = [];
  options: any[] = []

  modal_img!:any;
  img_width = '1545'
  img_value = 0;
  checked = false;
  
  constructor(private sadminservService:SadminservService, public datepipe: DatePipe, public router:Router) { }

  ngOnInit(): void {
    let current_date = this.datepipe.transform(this.date, 'yyyy-MM-dd') || '';
    this.set_date = String(current_date);
    this.sadminservService.get_employname().subscribe({next: (data)=>{
      console.log(data.Response.data)
      this.employee_list = data.Response.data
      for(let name_data of data.Response.data){
        this.options.push(name_data.name)
      }
      this.filteredOptions = this.options;
      },error: (e) => {
        var new_access_token = this.new_access_token('get_employname_fun')
        }
    });

    this.sadminservService.get_screenshot({"body":{'employid':this.employid, "date":this.set_date}}).subscribe({next: (data)=>{
      console.log(data.Response.data)
      this.date_list = data.Response.data
      },error: (e) => {
        var new_access_token = this.new_access_token('get_screenshot')
      }
    });
  }

  get_screenshot_fun(){
    this.sadminservService.get_screenshot({"body":{'employid':this.employid, "date":this.set_date}}).subscribe({next: (data)=>{
      console.log(data.Response.data)
      this.date_list = data.Response.data
      },error: (e) => {
        var new_access_token = this.new_access_token('get_screenshot')
      }
    });
  }

  get_employname_fun(){
    this.sadminservService.get_employname().subscribe({next: (data)=>{
      console.log(data.Response.data)
      this.employee_list = data.Response.data
      },error: (e) => {
        var new_access_token = this.new_access_token('get_employname_fun')
        }
    });
  }

  sort_icon_fun(data:any){
    this.sort_icon=!this.sort_icon
    this.sorting_type = data
  }

  new_access_token(data:any):void{
    this.sadminservService.refresh_api(localStorage.getItem('refresh_token')).subscribe({next: (data)=>{
      console.log(data)
      localStorage.setItem('access_token', data.Response.data.access_token);
      data()
    },
    error: (e) => {
        console.log(e);
        console.log(e.status);
        this.sadminservService.clear_refresh_token(e.status);
        this.router.navigate(['/login']);
      }
    });
  }

  month_onChange(result: any): void {
    console.log('onChange: ', result);
    let month = this.date.getMonth()+1;
    let year = this.date.getFullYear();
    let fullDate = `${year}-${month}`;
    if (`${month}`.length===1){
      let fullDate = `${year}-0${month}`;
    }
    
    this.set_date_value = fullDate
    console.log("set_date_value", this.set_date_value)
  }

  dateFormat = 'dd/MM/yyyy';
  monthFormat = 'yyyy/MM';
  isnzShowToday = true
  employee_screenshots(id:any){
    console.log(id);
    this.employid = id
    this.get_screenshot_fun()
  }
  onChange(result: Date): void {
    console.log('onChange: ', result);
    let new_date = this.datepipe.transform(result, 'yyyy-MM-dd') || '';
    this.set_date = String(new_date)

    this.get_screenshot_fun()
  } 


  onChange_autocomplite(value: string): void {
    console.log(this.options)
    this.filteredOptions = this.options.filter(option => option.toLowerCase().indexOf(value.toLowerCase()) !== -1);
  }

  isVisible = false;
  isConfirmLoading = false;

  showModal(img:any): void {
    this.isVisible = true;
    this.modal_img = img
  }

  handleOk(): void {
    this.isConfirmLoading = true;
    setTimeout(() => {
      this.isVisible = false;
      this.isConfirmLoading = false;
    }, 1000);
  }

  handleCancel(): void {
    this.isVisible = false;
  }

  zoom_in(){
    var new_width = Number(this.img_width)
    if (new_width<2500){
      new_width += 100
      this.img_value = new_width-1545
      console.log(this.img_value)
      this.img_width = String(new_width)
    }
  }

  zoom_out(){
    var new_width = Number(this.img_width)
    if (new_width>1545){
      new_width -= 100
      this.img_value = new_width-1545
      console.log(this.img_value)
      this.img_width = String(new_width)
    }
  }

  get_range_value(data:any){
    this.img_width = '1545'
    console.log(typeof data)
    var new_width = Number(this.img_width)
    new_width += data
    this.img_width = String(new_width)
  }

  detail_value(data:any){
    console.log(data);
  }
}

