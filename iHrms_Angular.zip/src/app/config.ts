export let config = {
    API_URL : "http://192.168.1.32:8000"
}