import { Component, OnInit } from '@angular/core';
import { ApicallService } from 'src/app/all-services/apicall.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { SadminservService } from 'src/app/all-services/sadminserv.service';
import { Meta, Title } from '@angular/platform-browser';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginresponse:any;
  loginerrorhidden = true
  passwordVisible = false;
  password?: string;

  constructor(private apicallService:ApicallService, public router:Router, public refreshtoken_api:SadminservService, private title: Title, private meta: Meta) { }

  LoginForm = new FormGroup({
    email : new FormControl(''),
    password : new FormControl(''),
    // remamber : new FormControl(false)
  })

  submitdata(){
    const formvalue = this.LoginForm.value;
    // const formData = new FormData();
    // formData.set('data', JSON.stringify(formvalue));
    console.log("form",formvalue);
    this.apicallService.loginapi(formvalue).subscribe(data=>{
      if(data.status == "Success" && (data.Response.data.usertype==2 || data.Response.data.usertype==1)){
        this.loginresponse=data;
        console.log('Employee_data', data.Response)
        localStorage.setItem('Employee_data', JSON.stringify(data.Response.data));
        localStorage.setItem('access_token', data.Response.data.access_token);
        localStorage.setItem('refresh_token', data.Response.data.refresh_token);
        this.router.navigate(['/superadmin/home']);
      }
      else{
        this.loginerrorhidden = false
      }
    })
  }
  ngOnInit(): void {
    this.title.setTitle("Product Page - This is the product page");
    this.meta.updateTag({ 
      name: 'description',
      content: 'This is the description'
  });


    var access_token = localStorage.getItem('access_token')
    var refresh_token = localStorage.getItem('refresh_token')
    if(access_token){
      // localStorage.clear();
      this.router.navigate(['/superadmin/home'], {skipLocationChange: true});
    }
  }

  login_block_right="login_block_right"
}
