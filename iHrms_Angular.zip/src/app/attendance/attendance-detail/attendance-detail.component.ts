import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NzModalRef, NzModalService } from 'ng-zorro-antd/modal';
import { NzTableFilterFn, NzTableSortFn, NzTableFilterList, NzTableSortOrder } from 'ng-zorro-antd/table';
import { SadminservService } from 'src/app/all-services/sadminserv.service';

interface DataItem {
  employid: string;
  name: string;
  date: string;
  In: string;
  Out: string;
  total_duration: string;
}


interface LeaveColumn {
  name: string;
  sortOrder: NzTableSortOrder | null;
  sortFn: NzTableSortFn<DataItem> | null;
  listOfFilter: NzTableFilterList;
  filterFn: NzTableFilterFn<DataItem> | null;
}


@Component({
  selector: 'app-attendance-detail',
  templateUrl: './attendance-detail.component.html',
  styleUrls: ['./attendance-detail.component.scss']
})

export class AttendanceDetailComponent implements OnInit {

  PageIndex = 1000;
  Total_data = 10;
  PageSize = 10;
  listOfData: DataItem[] = [];


  isVisible = false;
  isOkLoading = false;
  nzAutofocus = false
  footer = null

  editStr = 'More Details';


  constructor(private employee_id:ActivatedRoute, public router:Router, private sadminservService:SadminservService, private modal: NzModalService) { }

  ngOnInit(): void {
    this.all_attendance_record({"page_num":this.page_num, "page_size": this.PageSize})
  }

  // interface DataItem {
  //   employid: string;
  //   name: string;
  //   date: string;
  //   In: string;
  //   Out: string;
  //   total_duration: string;
  // }
  listOfColumn = [
    {
      title: 'EMPLOYEE',
      compare: null,
      priority: false
    },
    {
      title: 'DATE',
      compare: null,
      priority: false
    },
    {
      title: 'IN',
      compare: null,
      priority: false
    },
    {
      title: 'OUT',
      compare: null,
      priority: false
    },
    {
      title: 'DURATION',
      compare: null,
      priority: false
    },
    {
      title: 'MORE DETAILS',
      compare: null,
      priority: false
    },
    {
      title: 'CHANGE',
      compare: null,
      priority: false
    }
  ];

  showModal(): void {
    this.isVisible = true;
  }

  handleCancel(): void {
    this.isVisible = false;
  }

  handleOk(): void {
    this.isOkLoading = true;
    setTimeout(() => {
      this.isVisible = false;
      this.isOkLoading = false;
    }, 1000);
  }

  get_page_size(data:any){
    this.page_num=1
    this.PageSize = data
    this.all_attendance_record({"page_num":this.page_num, "page_size": this.PageSize})
  }


  page_num = 1
  get_page_num(data:any){
    console.log(data.target.text)
    if(data.target.text){
      this.page_num = Number(data.target.text)
      this.all_attendance_record({"page_num":this.page_num, "page_size": this.PageSize})
    }
  }

  all_attendance_record(data:any){
    this.sadminservService.all_attendance_record(data).subscribe({next: (data)=>{
    // console.log(data.Response.currentpage)
    // if(total_page>)
    this.listOfData = []
    this.listOfData = data.Response.data;
    this.PageIndex = data.Response.currentpage
    this.Total_data = data.Response.totalrecord
    this.PageSize = data.Response.parPage
    // console.log("this.listOfData", this.listOfData)
    },error: (e) => {
      console.log(e);
      console.log(e.status);
      var new_access_token = this.new_access_token()
      }
    });
  }


  new_access_token():void{
    this.sadminservService.refresh_api(localStorage.getItem('refresh_token')).subscribe({next: (data)=>{
      console.log(data)
      localStorage.setItem('access_token', data.Response.data.access_token);
      this.get_user_profile_data({"employid":"1001"})
    },
    error: (e) => {
        console.log(e);
        console.log(e.status);
        this.sadminservService.clear_refresh_token(e.status)
        this.router.navigate(['/login']);
      }
    });
  }

  user_name?:string;
  user_type?:string;
  user_id?:string;
  mobile_no?:string;
  user_email?:string;
  date_of_joining?:string;

  get_user_profile_data(data:any){
    this.sadminservService.get_profile_data({"body":data}).subscribe({next: (data)=>{
      console.log(data.Response)
      this.user_name = data.Response.data.name
      this.user_type = data.Response.data.user_type_name
      this.user_id = data.Response.data.employid
      this.mobile_no = data.Response.data.mobileno
      this.user_email = data.Response.data.email
      this.date_of_joining = data.Response.data.date_joining
    },error: (e) => {
      console.log(e);
      console.log(e.status);
      var new_access_token = this.new_access_token()
      }
    });
  }

  createCustomButtonModal(): void {
    const modal: NzModalRef = this.modal.create({
      // Preview
      nzTitle: 'More Details',
      nzContent: `<p class="border-start border-4 px-2 border-primary" style="font-weight: 500; font-size: 18px;">Punch In Details</p>
      <span class="text-primary" style="line-height: 30px;">IP : </span><span>202.131.97.66</span><br>
      <span class="text-primary" style="line-height: 30px;">Device : </span><span>Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) TrackWick/4.6.0 Chrome/66.0.3359.181 Electron/3.1.9 Safari/537.36</span><br>
      <span class="text-primary" style="line-height: 30px;">Platform : </span><span>DESKTOP</span><br>
      <span class="text-primary" style="line-height: 30px;">Address : </span><span>Ahmedabad, GJ, India, 380009</span><br>`,
      nzFooter: [],
      nzStyle:{"width":"1200px", "height": "600px"}
    });
  }
  
}

