import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AttendanceRoutingModule } from './attendance-routing.module';
import { MonthlyRecordComponent } from './monthly-record/monthly-record.component';
import { AttendanceDetailComponent } from './attendance-detail/attendance-detail.component';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzFormModule } from 'ng-zorro-antd/form';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NzUploadModule } from 'ng-zorro-antd/upload';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTypographyModule } from 'ng-zorro-antd/typography';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NgpSortModule } from "ngp-sort-pipe";



@NgModule({
  declarations: [
    MonthlyRecordComponent,
    AttendanceDetailComponent
  ],
  imports: [
    CommonModule,
    AttendanceRoutingModule,
    NzTableModule,
    NzDropDownModule,
    NzIconModule,
    NzSelectModule,
    NzPaginationModule,
    NzCardModule,
    NzRadioModule,
    NzButtonModule,
    NzFormModule,
    ReactiveFormsModule,
    FormsModule,
    NzUploadModule,
    DragDropModule,
    NzSwitchModule,
    NzToolTipModule,
    NzInputModule,
    NzDatePickerModule,
    NzTabsModule,
    NzTypographyModule,
    NzModalModule,
    NgpSortModule
  ]
})
export class AttendanceModule { }
