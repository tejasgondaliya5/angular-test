import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common'
import { SadminservService } from 'src/app/all-services/sadminserv.service';
import { Router } from '@angular/router';
import { differenceInCalendarDays, setHours } from 'date-fns';

import { DisabledTimeFn, DisabledTimePartial } from 'ng-zorro-antd/date-picker';


@Component({
  selector: 'app-monthly-record',
  templateUrl: './monthly-record.component.html',
  styleUrls: ['./monthly-record.component.scss']
})
export class MonthlyRecordComponent implements OnInit {
  attandance_icon = "assets/images/attandance-record-2.png"
  constructor(public datepipe: DatePipe, private sadminservService:SadminservService, public router:Router) { }

  date = new Date()
  ApiDate = this.datepipe.transform(new Date(), 'yyyy-MM') || '';;

  attendanceTypeArr = [
    {
      'sortName':"P",
      'fullName':"Present",
      'class' : "Present"
    },
    {
      'sortName':"",
      'fullName':"Late Mark",
      'class':"LateMark"
    },
    {
      'sortName':"HP",
      'fullName':"Half Day Present",
      'class':"Present"
    },
    {
      'sortName':"AB",
      'fullName':"Absent",
      'class':"Absent"
    },
    {
      'sortName':"",
      'fullName':"Deductions",
      'class':"Deductions"
    },
    {
      'sortName':"PA",
      'fullName':"Pending Approvals",
      'class':"PendingApprovals"
    },
    {
      'sortName':"L",
      'fullName':"Full Day Leave",
      'class':"FullDayLeave"
    },
    {
      'sortName':"HL",
      'fullName':"Half Day Leave",
      'class':"HalfDayLeave"
    },
    {
      'sortName':"",
      'fullName':"Paid Leave",
      'class':"PaidLeave"
    },
    {
      'sortName':"",
      'fullName':"Unpaid Leave",
      'class':"UnpaidLeave"
    },
    {
      'sortName':"H",
      'fullName':"Holiday",
      'class':"Holiday"
    },
    {
      'sortName':"",
      'fullName':"Non Working",
      'class':"NonWorking"
    },
    {
      'sortName':"",
      'fullName':"Not Joined",
      'class':"NotJoined"
    }
  ]
  // date = this.datepipe.transform(new Date(), 'yyyy-MM') || '';;
  
  onChange(result: Date): void {
    let new_date = this.datepipe.transform(result, 'yyyy-MM') || '';;
    this.ApiDate = new_date
    this.monthly_attendance_record()
  }

  listOfOption: string[] = [];
  listOfSelectedValue = [];

  tableHeader: string[]=[];
  tableData: any[]=[];
  employe_data: any[]=[];

  // disabledDate = (current: Date): boolean =>differenceInCalendarDays(current, this.today) > 0;

  // disabledDateTime: DisabledTimeFn = () => ({
  //   nzDisabledHours: () => this.range(0, 24).splice(4, 20),
  //   nzDisabledMinutes: () => this.range(30, 60),
  //   nzDisabledSeconds: () => [55, 56]
  // });


  ngOnInit(): void {

    const children: string[] = [];
    for (let i = 10; i < 36; i++) {
      children.push(`${i.toString(36)}${i}`);
    }
    this.listOfOption = children;
    this.monthly_attendance_record()
  }

  monthly_attendance_record(){
    this.sadminservService.monthly_attendance_record({"date":this.ApiDate}).subscribe({next: (data)=>{
    console.log(data.Response.data)
    this.tableHeader = data.Response.data.table_headers
    this.tableData = data.Response.data.attendace_data
    // this.employe_data = data.Response.data.attendace_data
    // console.log("this.listOfData", this.listOfData)
    },error: (e) => {
      console.log(e);
      console.log(e.status);
      var new_access_token = this.new_access_token()
      }
    });
  }

  new_access_token():void{
    this.sadminservService.refresh_api(localStorage.getItem('refresh_token')).subscribe({next: (data)=>{
      console.log(data)
      localStorage.setItem('access_token', data.Response.data.access_token);
      this.monthly_attendance_record()
    },
    error: (e) => {
        console.log(e);
        console.log(e.status);
        this.sadminservService.clear_refresh_token(e.status)
        this.router.navigate(['/login']);
      }
    });
  }

}
