import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApicallService } from './all-services/apicall.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {
  title = 'IHRMS';
  loader = "assets/images/spinner.gif"
  constructor(public router:Router){ }

  ngOnInit(): void {
    // if (localStorage.getItem('access_token')){
    //   this.router.navigate(['/superadmin/home']);
    // }
  }
}


