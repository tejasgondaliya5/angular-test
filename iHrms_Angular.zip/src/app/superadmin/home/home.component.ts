import { Component, OnInit } from '@angular/core';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';
import { SadminservService } from 'src/app/all-services/sadminserv.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common'
import { local_storage_data } from 'src/app/local_storage_data';
import { Meta, Title } from '@angular/platform-browser';


export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  first_arr = ['Productivity', ];

  second_arr = ['Birthdays', "Holidays"];

  third_arr = ['Attendance']
  holiday_set_date!:any;
  birthdaya_set_date!:any;

  birthDay!: Array<any>;
  holiDay!: Array<any>;
  get_local_storage_data = local_storage_data.localStorage_string_convert_json_formate()

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex,
      );
    }
  }

    constructor(private sadminservService:SadminservService, public router:Router, public datepipe: DatePipe, private title: Title, private meta: Meta) { 


    let current_date = this.datepipe.transform(this.date, 'yyyy-MM') || '';
    
    this.birthdaya_set_date = String(current_date);
    this.birthday_record({"date":this.birthdaya_set_date})

    this.holiday_set_date = String(current_date);
    this.holyday_record({"date":this.holiday_set_date})


  }

  optionList = [
    { label: 'Lucy', value: 'lucy', age: 20 },
    { label: 'Jack', value: 'jack', age: 22 }
  ];
  selectedValue = { label: 'Jack', value: 'jack', age: 22 };
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  compareFn = (o1: any, o2: any): boolean => (o1 && o2 ? o1.value === o2.value : o1 === o2);

  getdata(data:any){
    console.log(data.target.title);
  }

  birthday_record(data:any){
    this.sadminservService.birthday_record(data).subscribe({next: (data)=>{
    console.log(data.Response.data)
    this.birthDay = data?.Response?.data;
    // this.LeaveSummaryListOfData = []
    
    },error: (e) => {
      // console.log(e);
      // console.log(e.status);
      var new_access_token = this.new_access_token("birthday_record")
      }
    });
  }

  holyday_record(data:any){
    this.sadminservService.holyday_record(data).subscribe({next: (data)=>{
    console.log(data.Response.data)
    this.holiDay = data?.Response?.data;
    },error: (e) => {
      var new_access_token = this.new_access_token("holyday_record")
      }
    });
  }


  new_access_token(name:string):void{
    this.sadminservService.refresh_api(localStorage.getItem('refresh_token')).subscribe({next: (data)=>{
      console.log(data)
      localStorage.setItem('access_token', data.Response.data.access_token);
      if (name==="birthday_record"){
        this.birthday_record({"date":this.birthdaya_set_date})
      }
      if (name==="holyday_record"){
        this.holyday_record({"month":this.holiday_set_date})
      }
    },
    error: (e) => {
        console.log("access token error page inside ************************ :- ")
        console.log(e.status);
        this.sadminservService.clear_refresh_token(e.status)
        this.router.navigate(['/login']);
      }
    });
  }

  home_icon = "assets/images/home-icon.webp"
  three_dot = "assets/images/three.icon.svg"
  ngOnInit(): void {
    this.title.setTitle("home page - This is the home page");
    this.meta.updateTag({ 
      name: 'description',
      content: 'This is the home description'
    });
  }

  date = new Date();
  holidaya_date = new Date();
  attendance_date = new Date();
  
  onChange(result: any) {
    console.log('onChange: ', result);
  }

  month_onChange(result: any): void {
    console.log('onChange: ', result);
    let current_date = this.datepipe.transform(result, 'yyyy-MM') || '';
    this.birthdaya_set_date = String(current_date);
    this.birthday_record({"date":this.birthdaya_set_date})
  }

  holiday_month_onChange(result: any): void {
    console.log('onChange: ', result);
    let current_date = this.datepipe.transform(result, 'yyyy-MM') || '';
    this.holiday_set_date = String(current_date);
    this.holyday_record({"month":this.holiday_set_date})
  }

  attendance_month_onChange(result: any): void {
    console.log('onChange: ', result);
  }

}




