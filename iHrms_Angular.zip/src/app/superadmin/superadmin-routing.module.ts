import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AttendanceDetailComponent } from '../attendance/attendance-detail/attendance-detail.component';
import { MonthlyRecordComponent } from '../attendance/monthly-record/monthly-record.component';
import { ScreenshotsComponent } from '../desktop-insights/screenshots/screenshots.component';
import { DashbordComponent } from './dashbord/dashbord.component';
import { EmployeeComponent } from './employee/employee.component';
import { HomeComponent } from './home/home.component';
import { MainComponent } from './main/main.component';

const routes: Routes = [
  {
    path:"",
    component:MainComponent,
    children: [
      {
          path: 'home',
          component:HomeComponent
      },
      {
          path: 'dashbord',
          component:DashbordComponent
      },
      {
          path: 'employee',
          component:EmployeeComponent
      },
      {
          path: 'Emplpoyee',
          loadChildren: () => import('../employee-detail/employee-detail.module').then(m => m.EmployeeDetailModule)
      },
      {
        path: 'screenshots',
        component:ScreenshotsComponent
      },
      {
        path: 'attendance-detail',
        component:AttendanceDetailComponent
      },
      {
        path: 'monthlyAttendance',
        component:MonthlyRecordComponent
      },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SuperadminRoutingModule { }
