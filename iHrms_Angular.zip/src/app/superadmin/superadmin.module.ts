import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SuperadminRoutingModule } from './superadmin-routing.module';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { MainComponent } from './main/main.component';
import { EmployeeComponent } from './employee/employee.component';
import { DashbordComponent } from './dashbord/dashbord.component';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzButtonModule } from 'ng-zorro-antd/button';
import {MatButtonModule} from '@angular/material/button';
import {DragDropModule} from '@angular/cdk/drag-drop';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzProgressModule } from 'ng-zorro-antd/progress';
import { FormsModule } from '@angular/forms';
import { DesktopInsightsModule } from '../desktop-insights/desktop-insights.module';
import { AttendanceModule } from '../attendance/attendance.module';

@NgModule({
  declarations: [
    HeaderComponent,
    HomeComponent,
    MainComponent,
    EmployeeComponent,
    DashbordComponent
  ],

  imports: [
    CommonModule,
    FormsModule,
    SuperadminRoutingModule,
    NzTableModule,
    NzDropDownModule,
    NzIconModule,
    NzSelectModule,
    NzPaginationModule,
    NzCardModule,
    NzRadioModule,
    NzButtonModule,
    MatButtonModule,
    DragDropModule,
    NzDatePickerModule,
    NzProgressModule,
    DesktopInsightsModule,
    AttendanceModule
  ]
})

export class SuperadminModule { }

