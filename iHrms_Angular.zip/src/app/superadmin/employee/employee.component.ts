import { Component, OnInit } from '@angular/core';
import { NzTableFilterFn, NzTableFilterList, NzTableSortFn, NzTableSortOrder, NzTablePaginationPosition } from 'ng-zorro-antd/table';
import { map } from 'rxjs';
import { SadminservService } from 'src/app/all-services/sadminserv.service';
import { Router } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { local_storage_data } from 'src/app/local_storage_data';

interface DataItem {
  name: string;
  employid : string;
  email:string;
  status:string;
  usertype_name: string;
  app_version:string;
  desktop_version:string;
  work_location: string;
}

interface ColumnItem {
  name: string;
  sortOrder: NzTableSortOrder | null;
  sortFn: NzTableSortFn<DataItem> | null;
  listOfFilter: NzTableFilterList;
  filterFn: NzTableFilterFn<DataItem> | null;
  filterMultiple: boolean;
  sortDirections: NzTableSortOrder[];
}


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})
export class EmployeeComponent implements OnInit {
  radioValue = 'A';
  PageIndex = 10;
  Total_data = 50;
  PageSize = 10;

  
  listOfColumns: ColumnItem[] = [
    {
      name: 'Name',
      sortOrder: null,
      sortFn: (a: DataItem, b: DataItem) => a.name.localeCompare(b.name),
      sortDirections: ['ascend', 'descend', null],
      filterMultiple: true,
      listOfFilter: [],
      filterFn: null
    },
    {
      name: 'Identity',
      sortOrder: null,
      sortFn: (a: DataItem, b: DataItem) => a.employid.localeCompare(b.employid),
      sortDirections: ['ascend', 'descend', null],
      filterMultiple: true,
      listOfFilter: [],
      filterFn: null
    },
    {
      name: 'email',
      sortOrder: null,
      sortFn: (a: DataItem, b: DataItem) => a.email.localeCompare(b.email),
      sortDirections: ['ascend', 'descend', null],
      filterMultiple: true,
      listOfFilter: [],
      filterFn: null
    },
    {
      name: 'Status',
      sortOrder: null,
      sortFn: (a: DataItem, b: DataItem) => a.status.localeCompare(b.status),
      sortDirections: ['ascend', 'descend', null],
      filterMultiple: true,
      listOfFilter: [],
      filterFn: null
    },
    {
      name: 'Type',
      sortOrder: 'descend',
      sortFn: (a: DataItem, b: DataItem) => a.usertype_name.localeCompare(b.usertype_name),
      sortDirections: ['descend', null],
      listOfFilter: [],
      filterFn: null,
      filterMultiple: true
    },
    {
      name: 'App Version',
      sortOrder: 'descend',
      sortFn: (a: DataItem, b: DataItem) => a.app_version.localeCompare(b.app_version),
      sortDirections: ['descend', null],
      listOfFilter: [],
      filterFn: null,
      filterMultiple: true
    },
    {
      name: 'Desktop Version',
      sortOrder: 'descend',
      sortFn: (a: DataItem, b: DataItem) => a.desktop_version.localeCompare(b.desktop_version),
      sortDirections: ['descend', null],
      listOfFilter: [],
      filterFn: null,
      filterMultiple: true
    },
    {
      name: 'Address',
      sortOrder: null,
      sortDirections: ['ascend', 'descend', null],
      sortFn: (a: DataItem, b: DataItem) => a.work_location.length - b.work_location.length,
      filterMultiple: false,
      listOfFilter: [],
      filterFn: null
    }
  ];

  
  
  // listOfData: DataItem[] = []
  listOfData: DataItem[] = [];
  constructor(private sadminservService:SadminservService, public router:Router) { }

  new_access_token():void{
    this.sadminservService.refresh_api(localStorage.getItem('refresh_token')).subscribe({next: (data)=>{
      console.log(data)
      localStorage.setItem('access_token', data.Response.data.access_token);
      this.get_all_data_api()
    },
    error: (e) => {
        console.log(e);
        console.log(e.status);
        this.sadminservService.clear_refresh_token(e.status)
        this.router.navigate(['/login']);
      }
    });
  }

  get_all_data_api(){
    var store_data = local_storage_data.localStorage_string_convert_json_formate()
    this.sadminservService.get_all_data({"body":null}).subscribe({next: (data)=>{
      if(data.message == "authorization failed"){
        this.sadminservService.clear_refresh_token(408)
      }
      this.listOfData = data.Response.data;
      this.PageIndex = data.Response.currentpage
      this.Total_data = data.Response.totalrecord
      this.PageSize = data.Response.parPage
    },error: (e) => {
      console.log(e);
      console.log(e.status);
      var new_access_token = this.new_access_token()
      }
    });
  }

  ngOnInit(): void {
    this.get_all_data_api()
  }

}
