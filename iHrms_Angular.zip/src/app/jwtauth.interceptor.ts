import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { catchError, filter, take, switchMap } from "rxjs/operators";
import { Observable, throwError } from 'rxjs';


@Injectable()
export class JwtauthInterceptor implements HttpInterceptor {
  // intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
  //   return next.handle(request);
  // }
  intercept(req: HttpRequest<any>, next: HttpHandler):Observable<HttpEvent<unknown>> {
    console.log("Interception In Progress"); // Interception Stage
    const token = localStorage.getItem('access_token'); // This retrieves a token from local storage
    if(token){
      console.log("inside token")
    }
      req = req.clone({ headers: req.headers.set('Authorization', 'Bearer ' + token) });// This clones HttpRequest and Authorization header with Bearer token added      

      return next.handle(req).pipe(
            catchError((error: HttpErrorResponse) => {
                // Catching Error Stage
                if (error && error.status === 401) {
                    console.log("ERROR 401 UNAUTHORIZED") // in case of an error response the error message is displayed
                }
                const err = error.error.message || error.statusText;
                return throwError((error)); // any further errors are returned to frontend                    
            })
        );
      // }
  } 
  constructor() {}
}

